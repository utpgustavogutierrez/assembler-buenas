import re
from Clases import *


def LimpiarArchivo():
    with open("archivo_salida.asm", 'w'):
        pass
    with open("Output.hex","w"):
        pass

def CodigoOPPalabra(Palabra):
    OpCode = ""
    TipoR = ["add", "sub", "xor", "or", "and", "sll", "srl", "sra", "slt", "sltu","mul", "mulh", "mulsu", "mulu", "div", "divu", "rem", "remu"]
    TipoI1 = ["addi", "xori", "ori", "andi", "slli", "srli", "srai", "slti", "sltiu"]
    TipoI2 = ["lb", "lh", "lw", "lbu", "lhu"]
    TipoI3 = ["jalr"]
    TipoI4 = ["ecall","ebreak"]
    TipoJ = ["jal"]
    TipoS = ["sb","sh","sw"]
    TipoB = ["beq", "bne", "blt", "bge", "bltu", "bgeu"]
    TipoU1 = ["lui"]
    TipoU2 = ["auipc"]


    if Palabra in TipoR:
        OpCode = "0110011"
    elif Palabra in TipoI1:
        OpCode = "0010011"
    elif Palabra in TipoI2:
        OpCode = "0000011"
    elif Palabra in TipoI3:
        OpCode = "1100111"
    elif Palabra in TipoI4:
        OpCode = "1110011"
    elif Palabra in TipoJ:
        OpCode = "1101111"
    elif Palabra in TipoS:
        OpCode = "0100011"
    elif Palabra in TipoB:
        OpCode = "1100011"
    elif Palabra in TipoU1:
        OpCode = "0110111"
    elif Palabra in TipoU2:
        OpCode = "0010111"

    return OpCode

def EncontrarPalabra(linea):
    palabras = re.findall(r'\S+', linea)
    primeras_cuatro = palabras[:4]
    if len(primeras_cuatro) == 4 and re.match(r'^-?\d+$', primeras_cuatro[3]):
        if primeras_cuatro[3][-1] in '-':
            primeras_cuatro[3] = primeras_cuatro[3][:-1]
            primeras_cuatro.append('-')
    primeras_cuatro = [palabra.rstrip(',') for palabra in primeras_cuatro]
    return primeras_cuatro

def QuitarX(Palabra):
    PalabraSinX = re.sub(r'^x', '', Palabra)
    return int(PalabraSinX)

def EquivalenciaPalabra(Palabra):
    ABINAme = ["zero", "ra", "sp", "gp", "tp", "t0", "t1", "t2", "s0", "s1", "a0","a1", "a2","a3","a4","a5","a6","a7","s2","s3","s4","s5","s6","s7","s8","s9","s10","s11","t3","t4","t5", "t6"]
    Register = [f'x{i}' for i in range(32)]
    if Palabra == "fp":
        Palabra == "s0"
    if Palabra in ABINAme:
        return QuitarX(Register[ABINAme.index(Palabra)])
    else:
        return QuitarX(Palabra)
    



def QuitarLineasVacias():
    with open("input.asm", 'r') as ArchivoEntrada:
        with open("input2.asm", 'w') as ArchivoSalida:
            for Linea in ArchivoEntrada:
                if not re.match(r'^\s*$', Linea):
                    ArchivoSalida.write(Linea)


def IgnorarComentarios():
    Patron = r"[#;].*?$"
    with open("input2.asm", 'r') as ArchivoEntrada:
        with open("input3.asm", 'w') as ArchivoSalida:
            for linea in ArchivoEntrada:
                linea_sin_comentarios = re.sub(Patron, "", linea)
                ArchivoSalida.write(linea_sin_comentarios)

def IgnorarDirectivas():
  Patron = r"^\s*\."
  with open("input3.asm", 'r') as ArchivoEntrada:
            with open("input4.asm", 'w') as ArchivoSalida:
                for Linea in ArchivoEntrada:
                    if re.match(Patron, Linea):
                        continue
                    ArchivoSalida.write(Linea)

def IdentificarEtiquetas():
    Etiquetas = []
    Patron = re.compile(r'^\b(\w+):\s*$')
    with open("input4.asm", 'r') as ArchivoEntrada:
        for Linea in ArchivoEntrada:
            Linea = Linea.strip()
            match = Patron.search(Linea)
            if match:
                Etiqueta = match.group(1)
                Etiquetas += [Etiqueta]
    return Etiquetas

def Categorizar(Instrucciones):
    ClasesInstrucciones = []
    for Instruccion in Instrucciones:
        if Instruccion[4] == "0110011":
            Objeto = TipoR(Instruccion)
        if Instruccion[4] == "0010011" or Instruccion[4] == "0000011" or Instruccion[4] == "1100111" or Instruccion[4] == "1110011":
            Objeto = TipoI(Instruccion)
        if Instruccion[4] == "0100011":
            Objeto = TipoS(Instruccion)
        if Instruccion[4] == "1100011":
            Objeto = TipoB(Instruccion)
        if Instruccion[4] == "1101111":
            Objeto = TipoJ(Instruccion)
        if Instruccion[4] == "0110111" or Instruccion[4] == "0010111":
            Objeto = TipoU(Instruccion)
        ClasesInstrucciones += [Objeto]
    return ClasesInstrucciones

def IdentificarInstrucciones():
    Instruccion = []
    Instrucciones = []
    ClasesInstrucciones = []
    DireccionesMemoria = []
    DireccionMemoria = 0
    CodigoOP = ""
    Patron = r"([^:\s])[^\S]*$"
    with open("input4.asm", 'r') as ArchivoEntrada:
        for Linea in ArchivoEntrada:
            match = re.search(Patron, Linea)
            if match:
                DireccionesMemoria += [DireccionMemoria]
                DireccionMemoria += 4
                Instruccion = EncontrarPalabra(Linea)
                Instruccion[1] = EquivalenciaPalabra(Instruccion[1])
                Instruccion[2] = EquivalenciaPalabra(Instruccion[2])
                CodigoOP = CodigoOPPalabra(EncontrarPalabra(Linea)[0])
                if CodigoOP == "":
                    print("Instruccion no valida")
                    break
                Instruccion  += [CodigoOP]
                Instrucciones += [Instruccion]
                ClasesInstrucciones = Categorizar(Instrucciones)
    return ClasesInstrucciones, DireccionesMemoria



def EsEntero(cadena):
    patron = r'^-?\d+$'
    return bool(re.match(patron, cadena))

def ContarInstruccionesEtiqueta():
  instrucciones_por_etiqueta = {}
  InstruccionesEtiqueta = []
  InstruccionesEtiqueta2 = []
  i = 0
  Suma = 0
  with open("input4.asm", 'r') as archivo:
      etiqueta_actual = None
      for linea in archivo:
          linea = linea.strip()
          if linea.endswith(":"):
              etiqueta_actual = linea[:-1]
              instrucciones_por_etiqueta[etiqueta_actual] = 0
          elif linea:
              instrucciones_por_etiqueta[etiqueta_actual] += 1
  for Instruccion in instrucciones_por_etiqueta.values():
    Suma += Instruccion
    InstruccionesEtiqueta += [Instruccion]
    InstruccionesEtiqueta2 += [i*Suma]
    i = 1

  return InstruccionesEtiqueta2


def UltimaPalabra(CuartaPalabra,Etiquetas,Posicion):
    InstruccionesEtiqueta2 = ContarInstruccionesEtiqueta()
    NumeroAux = 0
    CuartaPalabra1 = 0
    if CuartaPalabra in Etiquetas:
        NumeroAux = Etiquetas.index(CuartaPalabra)
        CuartaPalabra1 = (InstruccionesEtiqueta2[NumeroAux]-1)*4
        CuartaPalabra = CuartaPalabra1 - Posicion * 4
    else:
        CuartaPalabra = EquivalenciaPalabra(CuartaPalabra)
    return CuartaPalabra



LimpiarArchivo()
QuitarLineasVacias()
IgnorarComentarios()
IgnorarDirectivas()
IdentificarEtiquetas()
ClasesInstrucciones,DireccionesMemoria = IdentificarInstrucciones()
Etiquetas = IdentificarEtiquetas()
Hexadecimal = ""
Salida = []
j = 0; x = 0
for i in ClasesInstrucciones:
    i.Instruccion[3] = UltimaPalabra(i.Instruccion[3],Etiquetas,j)
    j += 1
    i.RD()
    i.Funct3()
    i.RS1()
    i.RS2()
    i.IMM()
    if isinstance(i,TipoR):
        i.Funct7()

for i in ClasesInstrucciones:
    Hexadecimal = ''.join(i.Instruccion[4:])
    nombre_archivo = "Output.hex"
    with open(nombre_archivo, 'a') as archivo:
        archivo.write(Hexadecimal+'\n')