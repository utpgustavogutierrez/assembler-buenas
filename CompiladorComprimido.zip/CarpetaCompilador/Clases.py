import re

def DecimalABinario(NumeroDecimal):
    if NumeroDecimal == 0:
        return '0'
    
    bits = []
    numero_absoluto = abs(NumeroDecimal)
    while numero_absoluto > 0:
        residuo = numero_absoluto % 2
        bits.append(str(residuo))
        numero_absoluto //= 2
    
    bits.reverse()
    representacion_binaria = ''.join(bits)
    if NumeroDecimal < 0:
        longitud_binaria = len(representacion_binaria)
        representacion_binaria = '0' * (32 - longitud_binaria) + representacion_binaria
        representacion_binaria = ''.join(['1' if bit == '0' else '0' for bit in representacion_binaria])
        representacion_binaria = representacion_binaria.lstrip('0')
        representacion_binaria = '1' + representacion_binaria 
        representacion_binaria = bin(int(representacion_binaria, 2) + 1)[2:]
    
    return representacion_binaria or '0' 



def EsNegativo(cadena):
    patron = r'^-\d+(\.\d+)?$'
    return bool(re.match(patron, cadena))

def ComplementoA2(Palabra):
    print(Palabra)
    Palabra = Palabra.zfill(12)
    print(Palabra)
    for i in range(len(Palabra)):
        if Palabra[i] == "1":
            Palabra[i] == "0"
        else:
            Palabra[i] == "1"
    return(int(Palabra))

class Tipos:
    def __init__(self, Instruccion):
        self.Instruccion = Instruccion
    
    def RD(self):
        if isinstance(self,TipoS) or isinstance(self,TipoB):
            pass
        else:
            rd = (DecimalABinario(int(self.Instruccion[1]))).zfill(5)
            self.Instruccion.insert(4,rd)
        return self.Instruccion
    
    def RS1(self):
        if isinstance(self,TipoJ) or isinstance(self,TipoU):
            pass
        elif isinstance(self,TipoB):
            rs1 = (DecimalABinario(int(self.Instruccion[1]))).zfill(5)
            self.Instruccion.insert(4,rs1)
        else:
            rs1 = (DecimalABinario(int(self.Instruccion[2]))).zfill(5)
            self.Instruccion.insert(4,rs1)
        return self.Instruccion
    
    def RS2(self):
        if  isinstance(self,TipoR) or isinstance(self,TipoS):
            rs2 = DecimalABinario(int(self.Instruccion[3])).zfill(5)
            self.Instruccion.insert(4,rs2)
        elif isinstance(self,TipoB):
            rs2 = DecimalABinario(int(self.Instruccion[2])).zfill(5)
            self.Instruccion.insert(4,rs2)
        else:
            pass
        return self.Instruccion
    
    def Funct7(self):
        if self.Instruccion[0] == "sub" or self.Instruccion[0] == "sra":
            funct7 = "0100000"
        else:
            funct7 = "0000000"
        return self.Instruccion.insert(4,funct7)

    def Funct3(self):
        CodigoOP = self.Instruccion[4]
        if isinstance(self,TipoJ) or isinstance(self,TipoU):
            pass
        else:
            Palabra = self.Instruccion[0]
            PalabrasX1 = ["sll","slli","lh","sh","bne","mulh"]
            PalabrasX2 = ["slt","slti","lw","sw","mulsu"]
            PalabrasX3 = ["sltu","sltiu","mulu"]
            PalabrasX4 = ["xor","xori","lbu","blt","div"]
            PalabrasX5 = ["srl","sra","srli","srai","lhu","bge","divu"]
            PalabrasX6 = ["or","ori","vltu","rem"]
            PalabrasX7 = ["and","andi","bgeu","remu"]
            if Palabra in PalabrasX1:
                funct3 = "001"
            elif Palabra in PalabrasX2:
                funct3 = "010"
            elif Palabra in PalabrasX3:
                funct3 = "011"
            elif Palabra in PalabrasX4:
                funct3 = "100"
            elif Palabra in PalabrasX5:
                funct3 = "101"
            elif Palabra in PalabrasX6:
                funct3 = "110"
            elif Palabra in PalabrasX7:
                funct3 = "111"
            else:
                funct3 = "000"
            self.Instruccion.insert(4,funct3)
        return self.Instruccion

    def IMM(self):
        imm = ""
        if isinstance(self,TipoR):    
            pass
        else:
            if isinstance(self, TipoI):
                imm = DecimalABinario(int(self.Instruccion[3]))[-12:].zfill(12) 
            elif isinstance(self, TipoS):
                imm = DecimalABinario(int(self.Instruccion[3]))[-5:].zfill(5) 
                self.Instruccion.insert(-1, imm)
                imm = DecimalABinario(int(self.Instruccion[3]))[-12:-5].zfill(7) 
            elif isinstance(self, TipoB):
                imm = (DecimalABinario(int(self.Instruccion[3]))[-4:]+DecimalABinario(int(self.Instruccion[3]))[-12:-11]).zfill(5) 
                self.Instruccion.insert(-1, imm)
                imm = (DecimalABinario(int(self.Instruccion[3]))[-13:-12] + DecimalABinario(int(self.Instruccion[3]))[-11:-5]).zfill(7)
            elif isinstance(self, TipoU):
                imm = DecimalABinario(int(self.Instruccion[3]))[-32:-12].zfill(20) 
            elif isinstance(self, TipoJ):
                imm = DecimalABinario(int(self.Instruccion[3]))[-21:-20] + DecimalABinario(int(self.Instruccion[3]))[-11:-1] + DecimalABinario(int(self.Instruccion[3]))[-12:-11] + DecimalABinario(int(self.Instruccion[3]))[-20:-12] 
            self.Instruccion.insert(4, imm)
        
        return self.Instruccion


class TipoR(Tipos):
    def __init__(self, Instruccion):
        super().__init__(Instruccion)
        

class TipoI(Tipos):
    def __init__(self, Instruccion):
        super().__init__(Instruccion)


class TipoS(Tipos):
    def __init__(self, Instruccion):
        super().__init__(Instruccion)

class TipoB(Tipos):
    def __init__(self, Instruccion):
        super().__init__(Instruccion)

class TipoJ(Tipos):
    def __init__(self, Instruccion):
        super().__init__(Instruccion)

class TipoU(Tipos):
    def __init__(self, Instruccion):
        super().__init__(Instruccion)